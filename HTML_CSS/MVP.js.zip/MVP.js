//Time is set as military time

let time=2201
if(time < 1000){
    console.log("I want a latte");
}

if(time >= 1000 && time <= 1400){
    console.log("I want hot chocolate");
}
if(time > 1400 && time < 2200){
    console.log("I want ice cream");
}
if(time > 2200){
    console.log("I don't want anything other than sleep!");
}


    
