

function addLike(id){
    let el = document.querySelector(`#${id}`)
    console.log(el.innerText)
    el.innerText++
}